import React from "react";
import styles from "../styleDashboard/AddSuperVisor.module.css";
export default function AddSuperVisor() {
  return <div className={styles.AddSuperVisor}></div>;
}

import style from '../RegisterUser/RegisterUser.module.css';
import './FailedPin.css'
export default function FailedPin() {
    
  

  return (
    <>
    
    <div className={style.RegisterUser}>
  
    </div>
    </>
  );
}